# Student Organizer — Course Project

A UIKit + Storyboard iPhone app that keeps a student's **subjects**, **tasks** and **photo notes**, saved on the device with **Core Data**.

## Open and run

1. Unzip, then double-click `StudentOrganizer.xcodeproj`.
2. Pick an iPhone simulator and press **⌘R**.
3. If the storyboard shows yellow "frame will be different at run time" warnings, open `Main.storyboard`, click an empty spot on the canvas, then choose **Editor › Resolve Auto Layout Issues › Update Frames** (All Views in Container). The constraints are right; this only redraws the canvas.

Target: iOS 16.0, iPhone only, Portrait only. Core Data codegen: **Class Definition**.

## What is in the project

| File | Role |
| :--- | :--- |
| `CoreDataStack.swift` | Shared `NSPersistentContainer` and `viewContext`, plus `save()` |
| `Helpers.swift` | `showAlert`, `UIImage.resized(maxDimension:)`, `emptyStateLabel` |
| `StudentOrganizer.xcdatamodeld` | Entities `Subject`, `TaskItem`, `Note`, with Cascade/Nullify relationships |
| `SubjectsViewController.swift` | Subjects list, add with an alert, swipe to delete |
| `TasksViewController.swift` | Tasks for one subject, swipe right for Done/Undo, swipe left to delete |
| `TaskFormViewController.swift` | Add/edit form: text fields, date picker, segmented control, switch |
| `NotesViewController.swift` | Two-column `UICollectionView` grid |
| `NoteCell.swift` | Custom collection view cell (photo + text) |
| `NoteFormViewController.swift` | New note with a `PHPickerViewController` photo |
| `NoteDetailViewController.swift` | Full-size note, delete after a confirmation alert |

## Storyboard connections (already made in `Main.storyboard`)

**Segues** (all manual **Show** segues, drawn from the view controller icon):

| Identifier | From | To | Data passed |
| :--- | :--- | :--- | :--- |
| ShowTasksSegue | Subjects | Tasks | `subject` |
| ShowTaskFormSegue | Tasks | Task Form | `subject`, `taskToEdit` |
| ShowNotesSegue | Tasks | Notes | `subject` |
| ShowNoteFormSegue | Notes | Note Form | `subject` |
| ShowNoteDetailSegue | Notes | Note Detail | `note` |

**Outlets and actions**

| Scene | Connection | Control |
| :--- | :--- | :--- |
| Subjects | `addSubjectTapped:` | + bar button |
| Subjects | prototype cell | Subtitle, id `SubjectCell` |
| Tasks | `addTaskTapped:` / `notesTapped:` | + / Notes bar buttons |
| Tasks | prototype cell | Subtitle, id `TaskCell` |
| Task Form | `titleTextField`, `detailsTextField`, `dueDatePicker`, `prioritySegmentedControl`, `completedSwitch` | Stack view controls |
| Task Form | `saveTapped:` | Save bar button |
| Notes | `collectionView`, `addNoteTapped:` | Collection view, + bar button |
| Note cell | `photoImageView`, `noteLabel` | Class `NoteCell`, id `NoteCell` |
| Note Form | `noteTextView`, `photoImageView`, `choosePhotoTapped:`, `saveTapped:` | Text view, image view, Choose Photo button, Save |
| Note Detail | `photoImageView`, `dateLabel`, `noteLabel`, `deleteTapped:` | Image view, labels, Delete Note button |

## Test plan (Part G, Step 48)

| # | What to do | Expected result | Pass |
| :- | :--- | :--- | :-: |
| 1 | Add a subject | It appears in the list, sorted by name | ☐ |
| 2 | Save the subject alert with an empty name | Nothing is added; no crash | ☐ |
| 3 | Add a task with an empty title | "Title required" alert | ☐ |
| 4 | Add a task with a due date and High priority | Row shows the due date and "High" | ☐ |
| 5 | Swipe a task right, then right again | Checkmark, moves to bottom; Undo restores it | ☐ |
| 6 | Tap a task, change the title, Save | List shows the new title | ☐ |
| 7 | Swipe a task left | Task deleted | ☐ |
| 8 | Add a note with text only | Cell with a text icon | ☐ |
| 9 | Add a note with a photo | Photo in the grid and full-size in detail | ☐ |
| 10 | Delete a note from its detail screen | Confirmation, then the note is gone | ☐ |
| 11 | Stop and re-run the app | All data still there | ☐ |
| 12 | Delete a subject that has tasks and notes | Its tasks and notes are gone; other subjects unaffected | ☐ |
