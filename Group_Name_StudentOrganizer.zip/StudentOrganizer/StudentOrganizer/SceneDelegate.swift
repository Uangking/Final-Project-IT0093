import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    // The window and its root view controller come from Main.storyboard
    // (Info.plist -> UISceneStoryboardFile), so nothing has to be built in code here.
    func scene(_ scene: UIScene,
               willConnectTo session: UISceneSession,
               options connectionOptions: UIScene.ConnectionOptions) {
        guard let _ = (scene as? UIWindowScene) else { return }
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        // Safety net: every screen already saves right away, but if anything is still
        // pending when the student leaves the app, write it before iOS may suspend us.
        CoreDataStack.shared.save()
    }
}
